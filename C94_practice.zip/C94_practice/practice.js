
const firebaseConfig = {
  apiKey: "AIzaSyBQgV5gRn0xLARibGTBO4YgCRJ5g4tpM3A",
  authDomain: "kwitter-a4640.firebaseapp.com",
  databaseURL: "https://kwitter-a4640-default-rtdb.firebaseio.com",
  projectId: "kwitter-a4640",
  storageBucket: "kwitter-a4640.appspot.com",
  messagingSenderId: "532037779645",
  appId: "1:532037779645:web:ae5aa1a3176dfdf23577d4",
  measurementId: "G-QEYBQ3DMH3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

function addUser()
{
  user_name = document.getElementById("user_name").value;
  firebase.database().ref("/").child(user_name).update({
    purpose : "adding user"
  });
}


